package com.tm.shizukulite

import android.net.LocalSocket
import android.net.LocalSocketAddress
import java.io.DataInputStream
import java.io.DataOutputStream

/** API para falar com o servidor privilegiado. Chame fora da thread principal. */
object ShellClient {
    data class Result(val code: Int, val output: String)

    fun exec(command: String): Result {
        val s = LocalSocket()
        s.connect(LocalSocketAddress(ShellServer.SOCKET, LocalSocketAddress.Namespace.ABSTRACT))
        s.use {
            val out = DataOutputStream(it.outputStream)
            out.writeUTF(command)
            out.flush()
            val input = DataInputStream(it.inputStream)
            return Result(input.readInt(), input.readUTF())
        }
    }

    fun isRunning(): Boolean = try { exec("id").code == 0 } catch (_: Exception) { false }

    fun stop() { try { exec(ShellServer.CMD_STOP) } catch (_: Exception) {} }
}
