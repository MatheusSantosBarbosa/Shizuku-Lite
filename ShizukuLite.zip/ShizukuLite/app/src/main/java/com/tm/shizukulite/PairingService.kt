package com.tm.shizukulite

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.IBinder
import java.net.InetAddress
import java.net.NetworkInterface
import kotlin.concurrent.thread

/**
 * Fluxo (Android 11+):
 *  1. Descobre o serviço de pareamento do próprio aparelho via mDNS.
 *  2. Mostra uma notificação com campo para o código de 6 dígitos
 *     (assim você não precisa sair da tela de Depuração sem fio).
 *  3. Pareia, conecta por ADB e roda o start.sh -> ShellServer ativo.
 */
class PairingService : Service() {
    companion object {
        const val ACTION_PAIR = "com.tm.shizukulite.PAIR"
        const val ACTION_CONNECT = "com.tm.shizukulite.CONNECT"
        private const val EXTRA_PORT = "port"
        private const val KEY_CODE = "code"
        private const val CHANNEL = "pairing"
        private const val ID_MAIN = 1
        private const val ID_RESULT = 2
        private const val PAIRING_TYPE = "_adb-tls-pairing._tcp."

        fun start(ctx: Context, action: String? = null) {
            val i = Intent(ctx, PairingService::class.java).setAction(action)
            ctx.startForegroundService(i)
        }
    }

    private lateinit var nm: NotificationManager
    private var nsd: NsdManager? = null
    private var discovery: NsdManager.DiscoveryListener? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Pareamento ADB", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PAIR -> handlePair(intent)
            ACTION_CONNECT -> {
                foreground(note("Iniciando servidor via ADB..."))
                thread { runCatching { startServer() }.fold({ finish("Servidor iniciado.") }, { finish("Erro: ${it.message}") }) }
            }
            else -> {
                foreground(note("Procurando o pareamento... Abra Depuração sem fio > Parear com código."))
                startDiscovery()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopDiscovery()
        super.onDestroy()
    }

    // ---------- notificações ----------
    private fun note(text: String, action: Notification.Action? = null): Notification =
        Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Shizuku Lite")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .apply { if (action != null) addAction(action) }
            .build()

    private fun foreground(n: Notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_MAIN, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID_MAIN, n)
        }
    }

    private fun finish(text: String) {
        stopDiscovery()
        stopForeground(STOP_FOREGROUND_REMOVE)
        nm.notify(ID_RESULT, note(text))
        stopSelf()
    }

    // ---------- descoberta mDNS ----------
    @Suppress("DEPRECATION")
    private fun startDiscovery() {
        val m = getSystemService(NSD_SERVICE) as NsdManager
        nsd = m
        val l = object : NsdManager.DiscoveryListener {
            override fun onServiceFound(info: NsdServiceInfo) {
                m.resolveService(info, object : NsdManager.ResolveListener {
                    override fun onServiceResolved(r: NsdServiceInfo) {
                        if (isLocal(r.host)) askCode(r.port)
                    }
                    override fun onResolveFailed(i: NsdServiceInfo, code: Int) {}
                })
            }
            override fun onServiceLost(info: NsdServiceInfo) {}
            override fun onDiscoveryStarted(type: String) {}
            override fun onDiscoveryStopped(type: String) {}
            override fun onStartDiscoveryFailed(type: String, code: Int) { finish("Falha na busca (mDNS): $code") }
            override fun onStopDiscoveryFailed(type: String, code: Int) {}
        }
        discovery = l
        m.discoverServices(PAIRING_TYPE, NsdManager.PROTOCOL_DNS_SD, l)
    }

    private fun stopDiscovery() {
        discovery?.let { runCatching { nsd?.stopServiceDiscovery(it) } }
        discovery = null
    }

    /** Só aceita o serviço de pareamento deste próprio aparelho. */
    private fun isLocal(host: InetAddress?): Boolean {
        if (host == null) return false
        return NetworkInterface.getNetworkInterfaces().toList()
            .any { ni -> ni.inetAddresses.toList().any { it == host } }
    }

    private fun askCode(port: Int) {
        val input = RemoteInput.Builder(KEY_CODE).setLabel("Código de 6 dígitos").build()
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pi = PendingIntent.getService(
            this, 0,
            Intent(this, PairingService::class.java).setAction(ACTION_PAIR).putExtra(EXTRA_PORT, port),
            flags
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_send), "Digitar código", pi
        ).addRemoteInput(input).build()
        nm.notify(ID_MAIN, note("Serviço de pareamento encontrado (porta $port). Digite o código.", action))
    }

    // ---------- pareamento ----------
    private fun handlePair(intent: Intent) {
        val port = intent.getIntExtra(EXTRA_PORT, -1)
        val code = RemoteInput.getResultsFromIntent(intent)?.getCharSequence(KEY_CODE)?.toString()?.trim()
        if (port < 0 || code.isNullOrEmpty()) { finish("Código ou porta inválidos."); return }
        stopDiscovery()
        nm.notify(ID_MAIN, note("Pareando..."))
        thread {
            try {
                val adb = AdbManager.get(this)
                if (!adb.pair("127.0.0.1", port, code)) { finish("Pareamento falhou (código errado?)."); return@thread }
                startServer()
                finish("Pareado e servidor iniciado.")
            } catch (e: Exception) {
                finish("Erro: ${e.message}")
            }
        }
    }

    /** Conecta por ADB (porta descoberta via mDNS) e executa o start.sh. */
    private fun startServer() {
        val adb = AdbManager.get(this)
        val script = StartScript.write(this)
        if (!adb.isConnected && !adb.autoConnect(this, 10_000)) {
            throw IllegalStateException("não conectou ao ADB. A Depuração sem fio está ligada?")
        }
        val stream = adb.openStream("shell:sh ${script.absolutePath}")
        try {
            stream.openInputStream().readBytes() // espera o script terminar
        } finally {
            stream.close()
            adb.disconnect()
        }
    }
}
