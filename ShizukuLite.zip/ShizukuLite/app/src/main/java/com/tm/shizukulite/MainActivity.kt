package com.tm.shizukulite

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var input: EditText
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        status = TextView(this).apply { textSize = 20f }
        output = TextView(this).apply { setTextIsSelectable(true); typeface = android.graphics.Typeface.MONOSPACE }
        input = EditText(this).apply { hint = "Comando (ex: pm list packages)"; setSingleLine() }

        fun btn(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { action() }
        }

        root.addView(status)
        root.addView(btn("Parear por ADB sem fio (Android 11+)") { pairWireless() })
        root.addView(btn("Iniciar via ADB sem fio (já pareado)") { PairingService.start(this, PairingService.ACTION_CONNECT) })
        root.addView(btn("Iniciar via root (opcional)") { startRoot() })
        root.addView(btn("Gerar script / copiar comando ADB do PC") { copyAdb() })
        root.addView(btn("Verificar status") { refresh() })
        root.addView(btn("Parar servidor") { thread { ShellClient.stop(); refresh() } })
        root.addView(input, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(btn("Executar comando") { runCommand() })
        root.addView(output)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun show(text: String) = ui.post { output.text = text }

    private fun refresh() = thread {
        val r = try { ShellClient.exec("id") } catch (_: Exception) { null }
        ui.post { status.text = if (r != null) "● Ativo\n${r.output.trim()}" else "○ Parado" }
    }

    private fun pairWireless() {
        if (Build.VERSION.SDK_INT < 30) {
            show("Pareamento sem fio exige Android 11 ou superior. Use o comando ADB do PC.")
            return
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        PairingService.start(this)
        show(
            "1. Conecte-se a uma rede Wi-Fi.\n" +
            "2. Em Opções do desenvolvedor, ative Depuração sem fio.\n" +
            "3. Toque em \"Parear dispositivo com código\".\n" +
            "4. Abaixe a barra de notificações, toque em \"Digitar código\" e informe os 6 dígitos.\n\n" +
            "O servidor inicia sozinho depois do pareamento."
        )
        runCatching { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
    }

    private fun copyAdb() {
        StartScript.write(this)
        val cmd = StartScript.adbCommand(this)
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("adb", cmd))
        show("Script salvo e comando copiado:\n$cmd")
    }

    private fun startRoot() {
        val script = StartScript.write(this)
        thread {
            try {
                Runtime.getRuntime().exec(arrayOf("su", "-c", "sh ${script.absolutePath}")).waitFor()
                Thread.sleep(1500)
            } catch (e: Exception) {
                show("Root indisponível: ${e.message}")
            }
            refresh()
        }
    }

    private fun runCommand() {
        val cmd = input.text.toString().trim()
        if (cmd.isEmpty()) return
        thread {
            try {
                val r = ShellClient.exec(cmd)
                show("exit=${r.code}\n${r.output}")
            } catch (_: Exception) {
                show("Servidor não está ativo. Inicie pelo ADB, pareamento sem fio ou root.")
            }
        }
    }
}
