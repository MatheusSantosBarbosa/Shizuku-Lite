package com.tm.shizukulite

import android.net.LocalServerSocket
import android.net.LocalSocket
import java.io.DataInputStream
import java.io.DataOutputStream
import kotlin.concurrent.thread
import kotlin.system.exitProcess

/**
 * Roda FORA do app, via: app_process /system/bin com.tm.shizukulite.ShellServer <uidPermitido>
 * Herda o privilégio de quem iniciou (shell via ADB = uid 2000, ou root).
 * Escuta num socket abstrato e só aceita conexões do uid do próprio app.
 */
object ShellServer {
    const val SOCKET = "tm_shizuku_lite"
    const val CMD_STOP = "__stop__"

    @JvmStatic
    fun main(args: Array<String>) {
        val allowedUid = args[0].toInt()
        val server = LocalServerSocket(SOCKET)
        println("ShizukuLite ativo, uid=${android.os.Process.myUid()}")
        while (true) {
            val client = server.accept()
            thread { handle(client, allowedUid) }
        }
    }

    private fun handle(socket: LocalSocket, allowedUid: Int) {
        socket.use { s ->
            try {
                if (s.peerCredentials.uid != allowedUid) return
                val input = DataInputStream(s.inputStream)
                val output = DataOutputStream(s.outputStream)
                val cmd = input.readUTF()
                if (cmd == CMD_STOP) exitProcess(0)
                val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
                val out = p.inputStream.bufferedReader().readText().take(20000)
                output.writeInt(p.waitFor())
                output.writeUTF(out)
                output.flush()
            } catch (_: Exception) {
            }
        }
    }
}
