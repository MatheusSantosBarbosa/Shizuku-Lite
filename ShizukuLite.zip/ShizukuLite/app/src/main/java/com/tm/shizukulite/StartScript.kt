package com.tm.shizukulite

import android.content.Context
import java.io.File

/** Gera o start.sh que inicia o ShellServer via app_process. */
object StartScript {
    fun file(ctx: Context) = File(ctx.getExternalFilesDir(null), "start.sh")

    fun adbCommand(ctx: Context) =
        "adb shell sh /sdcard/Android/data/${ctx.packageName}/files/start.sh"

    fun write(ctx: Context): File {
        // "¤" é trocado por "$" para não conflitar com templates do Kotlin
        val script = """
            #!/system/bin/sh
            APK=¤(pm path ${ctx.packageName} | head -n1 | cut -d: -f2)
            pkill -f tm_server 2>/dev/null
            sleep 1
            CLASSPATH=¤APK nohup app_process /system/bin --nice-name=tm_server com.tm.shizukulite.ShellServer ${ctx.applicationInfo.uid} >/dev/null 2>&1 &
            echo "Shizuku Lite iniciado"
        """.trimIndent().replace('¤', '$')
        return file(ctx).also { it.writeText(script + "\n") }
    }
}
