plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tm.shizukulite"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.tm.shizukulite"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }
    buildTypes {
        release { isMinifyEnabled = false } // não minificar: o app_process precisa achar ShellServer
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // Pareamento e conexão ADB (TLS) dentro do app
    implementation("com.github.MuntashirAkon:libadb-android:1.0.1")
    implementation("com.github.MuntashirAkon:sun-security-android:1.1")
    implementation("org.conscrypt:conscrypt-android:2.5.2")
}
