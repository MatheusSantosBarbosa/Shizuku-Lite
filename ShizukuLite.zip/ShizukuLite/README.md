# Shizuku Lite

Abra a pasta no Android Studio (Koala+), deixe sincronizar o Gradle e rode no celular.
O Gradle baixa a lib de ADB pelo JitPack (precisa de internet na primeira sincronização).

## Iniciar o servidor (3 jeitos)
1. **ADB sem fio, tudo no celular (Android 11+)**: toque em *Parear por ADB sem fio*, ative
   Depuração sem fio > Parear com código e digite o código na notificação "Digitar código".
   Depois do primeiro pareamento, use *Iniciar via ADB sem fio (já pareado)*.
2. **ADB pelo PC**: *Gerar script / copiar comando* e rode o comando no PC.
3. **Root**: *Iniciar via root*.

Verifique em *Verificar status*: deve aparecer `uid=2000(shell)`.

## Arquitetura
- `ShellServer` roda via `app_process` fora do app e escuta num socket local abstrato; só aceita o uid do app.
- `ShellClient` é a API usada pelo app.
- `AdbManager` guarda a chave/certificado e faz pareamento + conexão (libadb-android).
- `PairingService` descobre o serviço de pareamento por mDNS, recebe o código pela notificação,
  pareia, conecta e roda o `start.sh`.

## Observações
- A Depuração sem fio precisa de Wi-Fi conectado (no Android 11 a opção desliga sem rede).
- Ao reiniciar o aparelho o servidor para; repita *Iniciar via ADB sem fio*.
